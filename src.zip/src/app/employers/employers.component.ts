import { Component, OnInit } from '@angular/core';
import { Employer } from '../model/employer.model';
import { EmployerService } from '../services/employer.service';
import { ActivatedRoute,Router } from '@angular/router';




@Component({
  selector: 'app-employers',
  templateUrl: './employers.component.html',
  styleUrls: ['./employers.component.css']
})
export class EmployersComponent implements OnInit {

  employers : Employer[]; //un tableau d'Employers
  constructor(private router :Router,private employerService: EmployerService) { 
    //this.employers = employerService.listeEmployers();


  }

  ngOnInit(): void {
    this.employerService.listeEmployers().subscribe(emps => {
      console.log(emps);
      this.employers = emps;
      });
      
  }

  supprimerEmployer(e: Employer)
{
  let conf = confirm("Etes-vous sûr ?");
  if (conf)
  this.employerService.supprimerEmployer(e.idEmployer).subscribe(() => {
  console.log("employé supprimé");
  this.SuprimerEmployerDuTableau(e);
  });
  
 

}

SuprimerEmployerDuTableau(emp : Employer) {
  this.employers.forEach((cur, index) => {
  if(emp.idEmployer=== cur.idEmployer) {
  this.employers.splice(index, 1);
  }
  });
  }

}
