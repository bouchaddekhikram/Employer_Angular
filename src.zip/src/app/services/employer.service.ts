import { Injectable } from '@angular/core';
import { Employer } from '../model/employer.model';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
const httpOptions = {
  headers: new HttpHeaders( {'Content-Type': 'application/json'} )
  };
@Injectable({
  providedIn: 'root'
})
export class EmployerService {
  apiURL: string = 'http://localhost:8080/employers/api';

  employers : Employer[]; 
  employer: Employer;
  constructor(private http : HttpClient) { 
    /*this.employers = [
      {idEmployer : 1, nomEmployer : "Amine", salaire : 3000.600, dateDebut : new Date("01/14/2011")},
{idEmployer : 2, nomEmployer : "Takwa", salaire : 450, dateDebut : new Date("12/17/2010")},
{idEmployer : 3, nomEmployer :"Ikram", salaire : 900.123, dateDebut : new Date("02/20/2020")}
    ];*/


  }

  listeEmployers():Observable<Employer[]>{
    //return this.employers;
    return this.http.get<Employer[]>(this.apiURL);
}
ajouterEmployer( emp: Employer):Observable<Employer>{
  return this.http.post<Employer>(this.apiURL, emp, httpOptions);
  }

supprimerEmployer(id: Number) {
  const url = `${this.apiURL}/${id}`;
return this.http.delete(url, httpOptions);
  }



  consulterEmployer(id: number): Observable<Employer> {
    const url = `${this.apiURL}/${id}`;
    return this.http.get<Employer>(url);
    }

  trierEmployers(){
    this.employers = this.employers.sort((n1,n2) => {
    if (n1.idEmployer > n2.idEmployer) {
    return 1;
    }
    if (n1.idEmployer < n2.idEmployer) {
    return -1;
    }
    return 0;
    });
    }

    updateEmployer(emp :Employer) : Observable<Employer>
    {
    return this.http.put<Employer>(this.apiURL, emp, httpOptions);
    }
  

}
