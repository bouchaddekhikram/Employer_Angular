import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployersComponent } from './employers/employers.component';
import { AddEmployerComponent } from './add-employer/add-employer.component';
import { UpdateEmployerComponent } from './update-employer/update-employer.component';
const routes: Routes = [
  {path: "employers", component : EmployersComponent},
  {path: "add-employer", component : AddEmployerComponent},
  {path: "updateEmployer/:id", component: UpdateEmployerComponent},
  { path: "", redirectTo: "employers", pathMatch: "full" }

  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
