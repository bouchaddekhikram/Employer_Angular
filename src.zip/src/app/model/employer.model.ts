export class Employer {
    idEmployer : number;
    nomEmployer : string;
    salaire : number;
     dateDebut : Date ;
    }