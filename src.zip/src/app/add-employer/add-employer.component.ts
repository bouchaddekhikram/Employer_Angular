import { Component, OnInit } from '@angular/core';
import { Employer } from '../model/employer.model';
import { EmployerService } from '../services/employer.service';
import { ActivatedRoute,Router } from '@angular/router';


@Component({
  selector: 'app-add-employer',
  templateUrl: './add-employer.component.html',
  styleUrls: ['./add-employer.component.css']
})
export class AddEmployerComponent implements OnInit {

  newEmployer = new Employer();
  message: string | undefined;

  constructor(private employerService: EmployerService, private router :Router) { }

  ngOnInit(): void {
  }

  addEmployer(){
    //console.log(this.newEmployer);
    //this.employerService.ajouterEmployer(this.newEmployer);

    this.employerService.ajouterEmployer(this.newEmployer).subscribe(emp => { 
    console.log(emp);
    });
    this.router.navigate(['employers']);

    this.message= " Employer "+ this.newEmployer.nomEmployer + " ajouté avec succèes!";
    }

}
