import { Component, OnInit } from '@angular/core';

import { ActivatedRoute,Router } from '@angular/router';
import { EmployerService } from '../services/employer.service';
import { Employer } from '../model/employer.model';

@Component({
  selector: 'app-update-employer',
  templateUrl: './update-employer.component.html',
  styles: [
  ]
})
export class UpdateEmployerComponent implements OnInit {

  currentEmployer = new Employer();
  constructor(private activatedRoute: ActivatedRoute,
    private router :Router,
    private employerService: EmployerService) { }

  ngOnInit(): void {

    this.employerService.consulterEmployer(this.activatedRoute.snapshot.params.id).
 subscribe( emp =>{ this.currentEmployer = emp; } ) ;
  }

  updateEmployer() {
    this.employerService.updateEmployer(this.currentEmployer).subscribe(emp => {
    this.router.navigate(['employers']);
    },(error) => { alert("Problème lors de la modification !"); }
    );
    }

}
